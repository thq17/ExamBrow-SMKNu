package id.sch.smknu.exambrow

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()
