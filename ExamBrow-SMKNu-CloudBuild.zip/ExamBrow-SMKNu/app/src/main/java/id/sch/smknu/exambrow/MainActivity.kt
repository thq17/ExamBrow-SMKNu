package id.sch.smknu.exambrow

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.text.InputType
import android.net.Uri

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("exam_brow_settings", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var webView: WebView? = null
    private val dpm by lazy { getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager }
    private val admin by lazy { ComponentName(this, AdminReceiver::class.java) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        showHome()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun setupRoot() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(Color.rgb(245, 248, 252))
        }
        setContentView(root)
    }

    private fun text(value: String, size: Float = 16f): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(Color.rgb(25, 42, 70))
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(10))
        }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
        }

    private fun field(hintText: String, value: String = "", password: Boolean = false): EditText =
        EditText(this).apply {
            hint = hintText
            setText(value)
            textSize = 16f
            setSingleLine(true)
            inputType = if (password) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        }

    private fun showHome() {
        stopWeb()
        setupRoot()
        root.addView(text("ExamBrow SMKNU 1.0", 25f))
        root.addView(text("Aplikasi ujian berbasis web", 15f))
        val url = prefs.getString("exam_url", "") ?: ""
        root.addView(text(if (url.isBlank()) "Link ujian belum diatur" else "Link ujian sudah tersimpan"))
        root.addView(button("MULAI UJIAN") {
            if (url.isBlank()) {
                Toast.makeText(this, "Masukkan link ujian melalui menu Setting terlebih dahulu.", Toast.LENGTH_LONG).show()
            } else {
                showExam(url)
            }
        })
        root.addView(button("SETTING") { askAdminPin() })
        root.addView(button("Aktifkan pengelolaan perangkat") { showAdminHelp() })
        root.addView(text("Untuk penguncian kiosk penuh, perangkat harus disiapkan oleh administrator.", 13f))
    }

    private fun askAdminPin() {
        val pinInput = field("PIN admin", password = true)
        AlertDialog.Builder(this)
            .setTitle("Verifikasi Admin")
            .setMessage("Masukkan PIN untuk membuka pengaturan.")
            .setView(pinInput)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Lanjut") { _, _ ->
                val saved = prefs.getString("admin_pin", "123456") ?: "123456"
                if (pinInput.text.toString() == saved) showSettings()
                else Toast.makeText(this, "PIN admin salah.", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showSettings() {
        setupRoot()
        root.addView(text("Pengaturan ExamBrow", 24f))
        val urlInput = field("https://alamat-ujian.sch.id", prefs.getString("exam_url", "") ?: "")
        root.addView(text("Link website ujian", 14f))
        root.addView(urlInput)
        val oldPin = prefs.getString("admin_pin", "123456") ?: "123456"
        val pinInput = field("PIN admin baru (minimal 4 digit)", oldPin, password = true)
        root.addView(text("PIN admin", 14f))
        root.addView(pinInput)
        root.addView(button("SIMPAN PENGATURAN") {
            val raw = urlInput.text.toString().trim()
            val normalized = if (raw.isNotEmpty() && !raw.startsWith("http://") && !raw.startsWith("https://")) "https://$raw" else raw
            val uri = runCatching { Uri.parse(normalized) }.getOrNull()
            if (uri == null || (normalized.isNotEmpty() && (uri.scheme !in listOf("https", "http") || uri.host.isNullOrBlank()))) {
                Toast.makeText(this, "Masukkan URL yang valid, contoh https://ujian.sekolah.id", Toast.LENGTH_LONG).show()
                return@button
            }
            if (pinInput.text.toString().length < 4) {
                Toast.makeText(this, "PIN minimal 4 karakter.", Toast.LENGTH_LONG).show()
                return@button
            }
            prefs.edit().putString("exam_url", normalized).putString("admin_pin", pinInput.text.toString()).apply()
            Toast.makeText(this, "Pengaturan tersimpan.", Toast.LENGTH_SHORT).show()
            showHome()
        })
        root.addView(button("Kembali") { showHome() })
    }

    private fun showExam(url: String) {
        setupRoot()
        root.setPadding(0, 0, 0, 0)
        root.setBackgroundColor(Color.WHITE)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(8), 0)
            setBackgroundColor(Color.rgb(20, 55, 100))
        }
        val title = text("ExamBrow • Ujian", 14f).apply { setTextColor(Color.WHITE) }
        bar.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
        val exit = Button(this).apply {
            text = "Keluar"
            isAllCaps = false
            setOnClickListener { confirmExitExam() }
        }
        bar.addView(exit)
        root.addView(bar)
        val wv = WebView(this)
        webView = wv
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.loadsImagesAutomatically = true
        wv.settings.javaScriptCanOpenWindowsAutomatically = false
        wv.settings.setSupportMultipleWindows(false)
        wv.settings.allowFileAccess = false
        wv.settings.allowContentAccess = false
        wv.webChromeClient = WebChromeClient()
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val target = request?.url ?: return true
                return target.scheme !in listOf("http", "https")
            }
        }
        root.addView(wv, LinearLayout.LayoutParams(-1, 0, 1f))
        wv.loadUrl(url)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
        try {
            if (dpm.isDeviceOwnerApp(packageName)) {
                dpm.setLockTaskPackages(admin, arrayOf(packageName))
                startLockTask()
            } else {
                // Android's screen-pinning prompt; full kiosk requires device-owner provisioning.
                startLockTask()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Mode kiosk belum diizinkan oleh administrator perangkat.", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmExitExam() {
        val pinInput = field("PIN admin", password = true)
        AlertDialog.Builder(this)
            .setTitle("Keluar dari ujian?")
            .setMessage("Hanya admin yang dapat menutup sesi ujian.")
            .setView(pinInput)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Keluar") { _, _ ->
                val saved = prefs.getString("admin_pin", "123456") ?: "123456"
                if (pinInput.text.toString() == saved) {
                    try { stopLockTask() } catch (_: Exception) {}
                    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
                    showHome()
                } else Toast.makeText(this, "PIN admin salah.", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showAdminHelp() {
        AlertDialog.Builder(this)
            .setTitle("Konfigurasi kiosk")
            .setMessage(
                "Mode kiosk penuh memerlukan perangkat khusus ujian dan pengaturan Device Owner melalui ADB/EMM. " +
                "Perintah ADB untuk perangkat yang baru di-reset tersedia di README proyek. " +
                "Jangan jalankan pada perangkat pribadi sebelum memahami dampaknya."
            )
            .setPositiveButton("Mengerti", null)
            .show()
    }

    private fun stopWeb() {
        webView?.apply { stopLoading(); destroy() }
        webView = null
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (webView != null) {
            // Deliberately do not navigate back during an exam.
            Toast.makeText(this, "Gunakan PIN admin untuk keluar dari ujian.", Toast.LENGTH_SHORT).show()
        } else {
            super.onBackPressed()
        }
    }
}
